<!doctype html>
<html lang="en">

<head>

    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="Sharia Economic Fair 2021 merupakan sebuah event mini talkshow yang dihadirkan oleh Sharfin, sebuah platform edukasi keuangan syariah kepada masyarakat agar bisa lebih mengenal ekonomi dan keuangan syariah lebih luas. Menghadirkan tokoh-tokoh berpengaruh dan inspiratif di industri keuangan syariah. Mengambil tema yang berjudul Sharia Economic Outlook 2021 dengan harapan kita bisa bangkit dan menyambut tahun 2021 dengan optimisme yang luar biasa setelah kita mengalami masa-masa yang sulit di 2020.">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="sharia economic fair, sef2021, sharia, economic, finance, sef sharfin, sharfinid, event sharfin, talkshow, lomba tiktok, tiktok challenge, belajar saham, investasi">
    <!--====== Title ======-->
    <title>SEF - Sharia Enconomic Fair 2021</title>

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!--====== Flaticon css ======-->
    <link rel="stylesheet" href="assets/css/flaticon.css">

    <!--====== Line Icons css ======-->
    <link rel="stylesheet" href="assets/css/LineIcons.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="assets/css/animate.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="assets/css/slick.css">

    <!--====== Default css ======-->
    <link rel="stylesheet" href="assets/css/default.css">

    <!--====== Style css ======-->
    <link rel="stylesheet" href="assets/css/style.css">

        <!--Floating WhatsApp css-->
    <link rel="stylesheet" href="assets/js/vendor/floating-wpp.min.css">

</head>

<body>

    <!--====== PRELOADER PART START ======-->

    <div class="preloader">
        <div class="loader">
            <div class="ytp-spinner">
                <div class="ytp-spinner-container">
                    <div class="ytp-spinner-rotator">
                        <div class="ytp-spinner-left">
                            <div class="ytp-spinner-circle"></div>
                        </div>
                        <div class="ytp-spinner-right">
                            <div class="ytp-spinner-circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--====== PRELOADER PART ENDS ======-->

    <!--====== HEADER PART START ======-->

    <header class="header-area">
        <div class="navbar-area navbar-two">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg">
                            <a class="navbar-brand" href="index.php">
                                <img src="assets/images/logo-white.svg" alt="Logo" height="65px">
                            </a>
                             <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTwo"
                                aria-controls="navbarTwo" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarTwo">
                                <ul class="navbar-nav">
                                    <li class="nav-item active">
                                        <a class="page-scroll" href="index.php">Beranda</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="page-scroll" href="#dokumen">Dokumen Pelatihan</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="page-scroll" href="#patner">Patner</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="page-scroll" href="#galeri">Galeri</a>
                                    </li>                                   
                                    <li class="nav-item">
                                        <a class="page-scroll" href="#faq">FAQ</a>
                                    </li>
                                </ul>
                            </div>
                        </nav> <!-- navbar -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div>
    </header>

    <!--====== HEADER PART ENDS ======-->
    <section id="banner">
        <div id="home" class="header-content-area bg_cover d-flex align-items-center"
            style="background-image: url(assets/images/header-bg-cgs.png)">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12"> 

                        <div class="header-content text-center">
                            <h2 class="header-title">JUDUL PELATIHAN</h2>
                            <h3 class="sub-title">Sub Judul Singkat</h3>
                            <h6 class="text-white mt-2">Jl. Malang No. 05, Malang, Jawa Timur, Indonesia</h6>
 
                        </div> <!-- header content -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- header content -->
    </section>
    <!--====== TIKTOK PART START ======-->
    
    <section id="deskripsi" class="about-area pb-130 pt-80">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <div class="about-content mt-45 wow fadeInRight" data-wow-duration="1s">
                        <div class="section-title">
                            <h2 class="title">Deskripsi Pelatihan </h2>
                            <p class="date">01 Januari 2021 s/d 01 Februari 2021</p>
                        </div> <!-- section title -->

                        <p class="text mt-30 mb-30">Keuangan Syariah selama ini selalu dianggap keilmuan yang kaku, yang tidak bisa relevan dengan perkembangan zaman, bahkan materi keuangan syariah selalu dianggap berat untuk dicerna. Dengan adanya platform tiktok yang aktif digunakan oleh millenial, kami ingin mengajak para pegiat keuangan syariah untuk mengenalkan keilmuan ini agar lebih ringan dicerna melalui platform Tiktok</p>
                       
                    </div> <!-- about content -->
                </div>
                
            </div> <!-- row -->
        </div> <!-- container -->
    </section>

    <!--====== TIKTOK PART ENDS ======-->
    <!--====== EVENT SCHEDULE PART START ======-->

    <section id="dokumen" class="event-schedule pt-115 pb-130">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section-title text-center">
                        <h2 class="title">Dokumen Pelatihan</h2>
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="event-tab mt-60">
                        <ul class="nav justify-content-center align-items-center" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="active" id="panduan-1-tab" data-toggle="tab" href="#panduan-1" role="tab"
                                    aria-controls="panduan-1" aria-selected="true">
                                    <h4 class="nav-title">Panduan</h4> 
                                </a>
                            </li>
                            <li class="nav-item">
                                <a id="kurikulum-2-tab" data-toggle="tab" href="#kurikulum-2" role="tab" aria-controls="kurikulum-2"
                                    aria-selected="false">
                                    <h4 class="nav-title">Kurikulum</h4> 
                                </a>
                            </li>
                            <li class="nav-item">
                                <a id="bahan-3-tab" data-toggle="tab" href="#bahan-3" role="tab" aria-controls="bahan-3"
                                    aria-selected="false">
                                    <h4 class="nav-title">Bahan Ajar</h4> 
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="panduan-1" role="tabpanel"
                                aria-labelledby="panduan-1-tab">
                                <div class="event-content pt-40">
                                    <div class="single-event d-md-flex mt-30">                                        
                                        <div class="event-content media-body">
                                            <h4 class="event-title">Panduan Peserta</h4>
                                            <p class="text pb-4">Silahkan download file dibawah sesuai kebutuhan anda...</p>
                                            <ul class="">
                                              <li class="pb-2"><a class="main-btn main-btn-2 btn-sm" href="#pricing">Download Rundown</a></li>
                                              <li class="pb-2"><a class="main-btn main-btn-2 btn-sm" href="#pricing">Download dokumen lain-lain</a></li> 
                                            </ul>
                                        </div>
                                    </div> <!-- single event -->

                                    <div class="single-event d-md-flex mt-30">                                        
                                        <div class="event-content media-body">
                                            <h4 class="event-title">Panduan Fasilitator</h4>
                                            <p class="text pb-4">Silahkan download file dibawah sesuai kebutuhan anda...</p>
                                            <ul class="">
                                              <li class="pb-2"><a class="main-btn main-btn-2 btn-sm" href="#pricing">Download panduan</a></li>
                                            </ul>
                                        </div>
                                    </div> <!-- single event -->
                                </div> <!-- event content -->
                            </div>
                            <div class="tab-pane fade" id="kurikulum-2" role="tabpanel" aria-labelledby="kurikulum-2-tab">
                                <div class="event-content pt-40">
                                    <div class="single-event d-md-flex mt-30"> 
                                        <div class="event-content media-body">
                                            <h4 class="event-title">Panduan Kurikulum</h4>
                                            <p class="text pb-4">Silahkan download file dibawah sesuai kebutuhan anda...</p>
                                            <ul class="">
                                              <li class="pb-2"><a class="main-btn main-btn-2 btn-sm" href="#pricing">Download panduan</a></li>
                                            </ul>
                                        </div>
                                    </div> <!-- single event --> 
                                </div> <!-- event content -->
                            </div>

                            <div class="tab-pane fade" id="bahan-3" role="tabpanel" aria-labelledby="bahan-3-tab">
                                <div class="event-content pt-40">
                                    <div class="single-event d-md-flex mt-30"> 
                                        <div class="event-content media-body">
                                             <h4 class="event-title">Bahan Ajar</h4>
                                            <p class="text pb-4">Silahkan download file dibawah sesuai kebutuhan anda...</p>
                                            <ul class="">
                                              <li class="pb-2"><a class="main-btn main-btn-2 btn-sm" href="#pricing">Download Materi 1</a></li>
                                              <li class="pb-2"><a class="main-btn main-btn-2 btn-sm" href="#pricing">Download Materi 2</a></li>
                                              <li class="pb-2"><a class="main-btn main-btn-2 btn-sm" href="#pricing">Download Materi 3</a></li>
                                            </ul>
                                        </div>
                                    </div> <!-- single event --> 
                                </div> <!-- event content -->
                            </div>
                        </div>
                    </div> <!-- event tab -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>

    <!--====== EVENT SCHEDULE PART ENDS ======-->

    <!--====== TEAM PART START ======-->

    <section id="patner" class="team-area pt-5 pb-130">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section-title text-center pb-20">
                        <h2 class="title">Partner Kerja</h2>
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->

            <div class="row">                
                <div class="col-lg-4 col-sm-6">
                    <div class="single-team text-center mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="1s">
                        <div class="team-image">
                            <img src="assets/images/speaker/melvin-mumpuni.png" alt="Team">
                        </div>
                        <div class="team-content">
                            <div class="team-social">

                            </div>
                            <h4 class="team-name"><a href="#">Melvin Mumpuni, CFP </a></h4>
                            <span class="sub-title">Founder @finansialku_com</span>
                        </div>
                    </div> <!-- single team -->
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="single-team text-center mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.5s">
                        <div class="team-image">
                            <img src="assets/images/speaker/dato-ahmed.png" alt="Speaker">
                        </div>
                        <div class="team-content">
                            <div class="team-social">

                            </div>
                            <h4 class="team-name"><a href="#">Prof Dato’ Ahmed K</a></h4>
                            <span class="sub-title">VP Waqafa International Sdn Bhd</span>
                        </div>
                    </div> <!-- single team -->
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="single-team text-center mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="0s">
                        <div class="team-image">
                            <img src="assets/images/speaker/abdus-salam.png" alt="Speaker">
                        </div>
                        <div class="team-content">
                            <h4 class="team-name"><a href="#">Abdus Salam</a></h4>
                            <span class="sub-title">Manager Keuangan KSPPS BMT UGT Nusantara</span>
                        </div>
                    </div> <!-- single team -->
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="single-team text-center mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.5s">
                        <div class="team-image">
                            <img src="assets/images/speaker/firman-siregar.png" alt="Team">
                        </div>
                        <div class="team-content">
                            <div class="team-social">

                            </div>
                            <h4 class="team-name"><a href="#">Firman Siregar</a></h4>
                            <span class="sub-title">Founder @kuliahsaham</span>
                        </div>
                    </div> <!-- single team -->
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="single-team text-center mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="1s">
                        <div class="team-image">
                            <img src="assets/images/speaker/jauhar-fikri.png" alt="Team">
                        </div>
                        <div class="team-content">
                            <div class="team-social">

                            </div>
                            <h4 class="team-name"><a href="#">Jauhar Fikri, CFP </a></h4>
                            <span class="sub-title">Founder @sharfinid</span>
                        </div>
                    </div> <!-- single team -->
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="single-team text-center mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="1.5s">
                        <div class="team-image">
                            <img src="assets/images/speaker/achmad-haris.png    " alt="Team">
                        </div>
                        <div class="team-content">
                            <div class="team-social">

                            </div>
                            <h4 class="team-name"><a href="#">Achmad Haris. S</a></h4>
                            <span class="sub-title">Investment Analyst @sharfinid</span>
                        </div>
                    </div> <!-- single team -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>

    <!--====== TEAM PART ENDS ======-->
    <section  id="galeri" class="team-area pt-5 pb-130">
      <div class="container ">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="section-title text-center pb-40">
                    <h2 class="title">Galeri</h2>
                </div> <!-- section title -->
            </div>
        </div>
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="assets/images/header-bg-cgs.png" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="assets/images/header-bg-cgs.png" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="assets/images/header-bg-cgs.png" alt="Third slide">
                </div> 
            </div>           
            
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
      </div>
    </section>
    <!--====== FOOTER PART START ======-->

    <section id="footer" class="footer-area bg_cover" style="background-image: url(assets/images/footer.jpg)">

        <div class="footer-widget">
            <div class="container">
                <div class="widget  pt-80 pb-130">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="footer-address mt-40">
                                <h5 class="f-title">Sharia Economic Fair</h5>
                                <p class="text">16 - 17 JANUARI, 2021</p>
                                <p class="text">0856 0782 2853 (Zakiyya)</p>
                            </div> <!-- footer address -->
                        </div>
                        <div class="col-lg-6">
                            <div class="footer-contact mt-40">
                                <h5 class="f-title">Info Lainnya</h5>
                                <ul class="social">
                                    <li><a href="#"><i class="lni-instagram-original"></i></a></li>
                                    <li><a href="#"><i class="lni-facebook-filled"></i></a></li>
                                    <li><a href="#"><i class="lni-youtube"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div> <!-- row -->
                </div> <!-- widget -->
            </div> <!-- container -->
        </div> <!-- footer widget -->

        <div class="footer-copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright text-center">
                            <p class="text">All Rights Reserved</p>
                        </div> <!-- copyright -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- container -->
    </section>

    <!--====== FOOTER PART ENDS ======-->

    <!--====== BACK TOP TOP PART START ======-->

        <div id='whatsapp-chat' class='hide'>
        <div class='header-chat'>
            <div class='head-home'>
                <h6>Salam!</h6>
                <p>Ada yang bisa kami bantu?</p>
            </div>
            <div class='get-new hide'>
                <div id='get-label'></div>
                <div id='get-nama'></div>
            </div>
        </div>
        <div class='home-chat'>
            <!-- Info Contact Start -->
            <a class='informasi' href='https://wa.me/6285607822853' title='Chat Whatsapp'>
                <div class='info-avatar'><img
                        src='assets/images/avatar.png' />
                </div>
                <div class='info-chat'>
                    <span class='chat-label'>Support</span>
                    <span class='chat-nama'>Zakiyya</span>
                </div><span class='my-number'>0856 0782 2853</span>
            </a>
            <!-- Info Contact End -->
            <div class='blanter-msg'><a href="https://wa.me/6285607822853">Clik disini untuk Hubungi <strong>0856 0782 2853</strong></a></div>
        </div>
        <div id='get-number'></div><a class='close-chat' href='javascript:void'>×</a>
    </div>
    <a class='blantershow-chat' href='javascript:void' title='Show Chat'><i class='lni-whatsapp'></i>Hubungi Kami</a>

    <!--====== BACK TOP TOP PART ENDS ======-->

 

    <!--====== jquery js ======-->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/popper.min.js"></script>

    <!--====== Counter Up js ======-->
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>

    <!--====== Slick js ======-->
    <script src="assets/js/slick.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Scrolling Nav js ======-->
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/scrolling-nav.js"></script>

    <!--====== Countdown js ======-->
    <script src="assets/js/jquery.countdown.min.js"></script>

    <!--====== wow js ======-->
    <script src="assets/js/wow.min.js"></script>

    <!--====== Ajax Contact js ======-->
    <script src="assets/js/ajax-contact.js"></script>

    <!--====== Main js ======-->
    <script src="assets/js/main.js"></script> 
    

        <script>
        $(document).on("click", "#send-it", function () {
            var a = document.getElementById("chat-input");
            if ("" != a.value) {
                var b = $("#get-number").text(),
                    c = document.getElementById("chat-input").value,
                    d = "https://web.whatsapp.com/send",
                    e = b,
                    f = "&text=" + c;
                if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))
                    var d = "whatsapp://send";
                var g = d + "?phone=" + e + f;
                window.open(g, '_blank')
            }
        }), $(document).on("click", ".informasi", function () {
            document.getElementById("get-number").innerHTML = $(this).children(".my-number").text(), document.getElementById("get-nama").innerHTML = $(this)
                .children(".info-chat").children(".chat-nama").text(), document.getElementById("get-label")
                .innerHTML = $(this).children(".info-chat").children(".chat-label").text()
        }), $(document).on("click", ".close-chat", function () {
            $("#whatsapp-chat").addClass("hide").removeClass("show")
        }), $(document).on("click", ".blantershow-chat", function () {
            $("#whatsapp-chat").addClass("show").removeClass("hide")
        });
    </script>
  <script>
      $(".navbar-nav a").on("click", function(){
      $(".navbar-nav").find(".active").removeClass("active");
      $(this).parent().addClass("active");
    });
  </script>
</body>

</html>