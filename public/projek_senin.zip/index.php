<!doctype html>
<html lang="en">

<head>

    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="Sharia Economic Fair 2021 merupakan sebuah event mini talkshow yang dihadirkan oleh Sharfin, sebuah platform edukasi keuangan syariah kepada masyarakat agar bisa lebih mengenal ekonomi dan keuangan syariah lebih luas. Menghadirkan tokoh-tokoh berpengaruh dan inspiratif di industri keuangan syariah. Mengambil tema yang berjudul Sharia Economic Outlook 2021 dengan harapan kita bisa bangkit dan menyambut tahun 2021 dengan optimisme yang luar biasa setelah kita mengalami masa-masa yang sulit di 2020.">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="facebook-domain-verification" content="u6l4wb5m9m0iu105t5ib8az7lupbbn" />
    <!--====== Title ======-->
    <meta name="keywords" content="shariaeconomicfair, sharia economic fair, sef2021, sharia, economic, finance, sef sharfin, sharfinid, event sharfin, talkshow, lomba tiktok, tiktok challenge, belajar saham, investasi">
    <title>SEF - Sharia Enconomic Fair 2021</title>

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!--====== Flaticon css ======-->
    <link rel="stylesheet" href="assets/css/flaticon.css">

    <!--====== Line Icons css ======-->
    <link rel="stylesheet" href="assets/css/LineIcons.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="assets/css/animate.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="assets/css/slick.css">

    <!--====== Default css ======-->
    <link rel="stylesheet" href="assets/css/default.css">

        <!--Floating WhatsApp css-->
    <link rel="stylesheet" href="assets/js/vendor/floating-wpp.min.css">

    <!--====== Style css ======-->
    <link rel="stylesheet" href="assets/css/style.css">


</head>

<body>

    <!--====== PRELOADER PART START ======-->

    <div class="preloader">
        <div class="loader">
            <div class="ytp-spinner">
                <div class="ytp-spinner-container">
                    <div class="ytp-spinner-rotator">
                        <div class="ytp-spinner-left">
                            <div class="ytp-spinner-circle"></div>
                        </div>
                        <div class="ytp-spinner-right">
                            <div class="ytp-spinner-circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--====== PRELOADER PART ENDS ======-->

    <!--====== HEADER PART START ======-->

    <header class="header-area">
        <div class="navbar-area navbar-two">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg">
                            <a class="navbar-brand" href="index.php">
                                <img src="assets/images/logo-cgs-white.png" alt="Logo" height="65px">
                            </a>

                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTwo"
                                aria-controls="navbarTwo" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarTwo">
                                <ul class="navbar-nav ">
                                    <li class="nav-item active">
                                        <a class="page-scroll" href="#home">Beranda</a>
                                    </li> 
                                     <li class="nav-item">
                                        <a class="page-scroll" href="#pelatihan">Pelatihan</a>
                                    </li> 
                                </ul>
                            </div>
                        </nav> <!-- navbar -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> 
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="assets/images/header-bg-cgs.png" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="assets/images/header-bg-cgs.png" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="assets/images/header-bg-cgs.png" alt="Third slide">
                </div> 
            </div>           
             
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div> 
    </header>

    <!--====== HEADER PART ENDS ======-->
    <!--====== FEATURES PART START ======-->

    <section id="pelatihan" class="features-area pt-115 pb-130 gray-bg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section-title text-center pb-20">
                        <h2 class="title">Daftar Pelatihan</h2>
                        <p class="text">Tidak hanya mengikuti pelatihan saja, anda juga akan mendapat banyak ilmu ketika mendaftar pada pelatihan ini</p>
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <a href="pelatihan.php"  class="single-features text-center mt-30 wow fadeIn" data-wow-duration="1s"
                        data-wow-delay="0s">
                        <div class="features-icon">
                            <i class="lni-certificate"></i>
                            <span>01</span>
                        </div>
                        <div class="features-content">
                            <h4 class="features-title">Free E-Certificate</h4>
                            <p class="text">Akan ada e-sertifikat di setiap sesi (total 4 sesi) yang akan anda dapatkan</p>
                        </div>
                    </a> <!-- single features -->
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="single-features text-center mt-30 wow fadeIn" data-wow-duration="1s"
                        data-wow-delay="0.5s">
                        <div class="features-icon">
                            <i class="lni-certificate"></i>
                            <span>02</span>
                        </div>
                        <div class="features-content">
                            <h4 class="features-title"><a href="#">Mentoring Investasi</a></h4>
                            <p class="text">Setelah acara, anda masih akan mendapatkan benefit dengan mentoring investasi selama 1 bulan</p>
                        </div>
                    </div> <!-- single features -->
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="single-features text-center mt-30 wow fadeIn" data-wow-duration="1s"
                        data-wow-delay="1s">
                        <div class="features-icon">
                            <i class="lni-certificate"></i>
                            <span>03</span>
                        </div>
                        <div class="features-content">
                            <h4 class="features-title"><a href="#">Ebook Analisa Saham</a></h4>
                            <p class="text">Ini adalah contoh ebook analisa perusahaan untuk PT Bank Syariah Indonesia, Tbk</p>
                        </div>
                    </div> <!-- single features -->
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="single-features text-center mt-30 wow fadeIn" data-wow-duration="1s"
                        data-wow-delay="0.5s">
                        <div class="features-icon">
                            <i class="lni-pie-chart"></i>
                            <span>04</span>
                        </div>
                        <div class="features-content">
                            <h4 class="features-title"><a href="#">Free Excel Perencanaan Keuangan</a></h4>
                            <p class="text">Anda juga akan mendapatkan excel yang dapat membantu anda dalam membuat perencanaan keuangan</p>
                        </div>
                    </div> <!-- single features -->
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="single-features text-center mt-30 wow fadeIn" data-wow-duration="1s"
                        data-wow-delay="1s">
                        <div class="features-icon">
                            <i class="lni-certificate"></i>
                            <span>05</span>
                        </div>
                        <div class="features-content">
                            <h4 class="features-title"><a href="#">Free Konsultasi Keuangan</a></h4>
                            <p class="text">Selama 1 bulan, anda akan mendapatkan free konsultasi keuangan.  </p>
                        </div>
                    </div> <!-- single features -->
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="single-features text-center mt-30 wow fadeIn" data-wow-duration="1s"
                        data-wow-delay="1.5s">
                        <div class="features-icon">
                            <i class="lni-certificate"></i>
                            <span>06</span>
                        </div>
                        <div class="features-content">
                            <h4 class="features-title"><a href="#">Grup Diskusi Aktif</a></h4>
                            <p class="text">Nantinya anda akan dimasukkan ke dalam grup diskusi yang mana banyak manfaat ketika ada di grup tersebut</p>
                        </div>
                    </div> <!-- single features -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section> 
    <!--====== FEATURES PART ENDS ======-->

    <!--====== FOOTER PART ENDS ======-->

    <!--====== BACK TOP TOP PART START ======-->

    <div id='whatsapp-chat' class='hide'>
        <div class='header-chat'>
            <div class='head-home'>
                <h6>Salam!</h6>
                <p>Ada yang bisa kami bantu?</p>
            </div>
            <div class='get-new hide'>
                <div id='get-label'></div>
                <div id='get-nama'></div>
            </div>
        </div>
        <div class='home-chat'>
            <!-- Info Contact Start -->
            <a class='informasi' href='https://wa.me/6285607822853' title='Chat Whatsapp'>
                <div class='info-avatar'><img
                        src='assets/images/avatar.png' />
                </div>
                <div class='info-chat'>
                    <span class='chat-label'>Support</span>
                    <span class='chat-nama'>Zakiyya</span>
                </div><span class='my-number'>0856 0782 2853</span>
            </a>
            <!-- Info Contact End -->
            <div class='blanter-msg'><a href="https://wa.me/6285607822853">Clik disini untuk Hubungi <strong>0856 0782 2853</strong></a></div>
        </div>
        <div id='get-number'></div><a class='close-chat' href='javascript:void'>×</a>
    </div>
    <a class='blantershow-chat' href='javascript:void' title='Show Chat'><i class='lni-whatsapp'></i>Hubungi Kami</a>

    <!--====== BACK TOP TOP PART ENDS ======-->

    <!--====== jquery js ======-->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/popper.min.js"></script>

    <!--====== Counter Up js ======-->
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>

    <!--====== Slick js ======-->
    <script src="assets/js/slick.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Scrolling Nav js ======-->
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/scrolling-nav.js"></script>

    <!--====== Countdown js ======-->
    <script src="assets/js/jquery.countdown.min.js"></script>

    <!--====== wow js ======-->
    <script src="assets/js/wow.min.js"></script>

    <!--====== Ajax Contact js ======-->
    <script src="assets/js/ajax-contact.js"></script>

    <!--====== Main js ======-->
    <script src="assets/js/main.js"></script>

    <!-- Facebook Pixel Code -->
    <script> 
        // !function(f,b,e,v,n,t,s)
        // {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        // n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        // if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        // n.queue=[];t=b.createElement(e);t.async=!0;
        // t.src=v;s=b.getElementsByTagName(e)[0];
        // s.parentNode.insertBefore(t,s)}(window,document,'script',
        // 'https://connect.facebook.net/en_US/fbevents.js');
        // fbq('init', '734768103834405'); 
        // fbq('track', 'PageView');   
    </script> 
    
    <script type="text/javascript">     

    $('#detailTalk').click(function() {
        // fbq('track', 'ViewContent');
        window.location.href('talkshow.php');
    });

    $('#detailTiktok').click(function() {
        // fbq('track', 'ViewContent');
        window.location.href('lomba.php');
    });

    $('#beliTiketsatu').click(function() {

        // google
         
        // gtag('event', 'conversion', {
        //     'send_to': 'AW-450492567/nvgDCIucu-8BEJfx59YB',
        //     'value':1.0,
        //     'currency': 'USD'
        // });
        // fb

        // fbq('track', 'Purchase', {currency: "IDR", value: 100000});
        window.open('http://bit.ly/sef-sharfin', '_blank');
        
    });

    $('#beliTiketdua').click(function() {
        // google
         
        // gtag('event', 'conversion', {
        //     'send_to': 'AW-450492567/TVfTCJmkzu8BEJfx59YB',
        //     'value':1.5 ,
        //     'currency': 'USD'
        // });
        // fb
        // fbq('track', 'Purchase', {currency: "IDR", value: 150000});
        window.open('http://bit.ly/sef-sharfin', '_blank')
    });

    $('#beliKontak').click(function() {
        // fbq('track', 'Contact');
        window.open('http://Wa.me/6285607822853', '_blank');
    });

    </script>
    
    <!-- End Facebook Pixel Code -->

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-PT35WK2PFX"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-PT35WK2PFX');
    </script>

    <!-- Global site tag (gtag.js) - Google Ads: 450492567 --> 
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-450492567">
    </script> 
    <script> 
        window.dataLayer = window.dataLayer || []; 
        function gtag(){
            dataLayer.push(arguments);
        } 
        gtag('js', new Date()); 
        gtag('config', 'AW-450492567'); 
    </script>

    <script>
        $(document).on("click", "#send-it", function () {
            var a = document.getElementById("chat-input");
            if ("" != a.value) {
                var b = $("#get-number").text(),
                    c = document.getElementById("chat-input").value,
                    d = "https://web.whatsapp.com/send",
                    e = b,
                    f = "&text=" + c;
                if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))
                    var d = "whatsapp://send";
                var g = d + "?phone=" + e + f;
                window.open(g, '_blank')
            }
        }), $(document).on("click", ".informasi", function () {
            document.getElementById("get-number").innerHTML = $(this).children(".my-number").text(), document.getElementById("get-nama").innerHTML = $(this)
                .children(".info-chat").children(".chat-nama").text(), document.getElementById("get-label")
                .innerHTML = $(this).children(".info-chat").children(".chat-label").text()
        }), $(document).on("click", ".close-chat", function () {
            $("#whatsapp-chat").addClass("hide").removeClass("show")
        }), $(document).on("click", ".blantershow-chat", function () {
            $("#whatsapp-chat").addClass("show").removeClass("hide")
        });
    </script>
  <script>
      $(".navbar-nav a").on("click", function(){
      $(".navbar-nav").find(".active").removeClass("active");
      $(this).parent().addClass("active");
    });
  </script>
</body>

</html>